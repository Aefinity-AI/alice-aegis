---
name: alice-unikernel
description: Development, debugging, and grant-review preparation guide for the A.L.I.C.E. unikernel — a no_std Rust, bare-metal UEFI LLM inference engine running BitNet b1.58-2B-4T with hand-written AVX2 ternary kernels. Use this skill whenever a task touches this project in any way; the aegis-core, aegis-forge, aegis-uefi, aegis-eval, aegis-linux, or antigravity crates; ternary/AVX2 kernels, prefill/decode paths, KV cache, tokenizer, or vocabulary pruning; MODEL.SAF, EMBED.BIN, or VOCAB.BIN; UEFI boot, DMA bounce buffers, FAT32 loading, physical memory allocation, or xsetbv/AVX enablement; benchmarks, perplexity, tokens/sec, or any performance measurement; or preparing DARPA / Phase I / grant-review materials, proposals, or demo scripts. Also use it when the user says ALICE, Aegis, Antigravity, BitNet-on-bare-metal, or asks to make the unikernel faster, more coherent, more boot-compatible, or review-ready.
---

# A.L.I.C.E. Unikernel — Project Skill

A.L.I.C.E. is a real, working `no_std` bare-metal LLM: a Rust UEFI application that
boots directly on x86_64 hardware (no OS), loads Microsoft's BitNet b1.58-2B-4T
ternary weights from a USB FAT32 volume, and runs inference with hand-written AVX2
kernels and a custom physical-memory allocator. The engineering is genuinely strong.
The project's goal is a fundable Phase I grant package, which means the work has two
inseparable halves: making the system fast/correct, and making every claim about it
**verifiable**.

## Repo map

| Crate / path | Role | Environment |
|---|---|---|
| `aegis-core` | Inference engine: arena, attention, ops (AVX2 kernels), tokenizer, sampler | `no_std` + `alloc` |
| `aegis-uefi` | UEFI boot app: AVX enable, DMA bounce buffer, file loading, allocator, interactive CLI | `no_std`, `uefi` crate |
| `aegis-forge` | Offline prep: vocabulary pruning + embedding slicing → `vocab.bin` / `embed.bin` / pruned config | std |
| `aegis-eval` | Perplexity harness (WikiText-2) | std |
| `aegis-linux` | Host-side runner for the engine | std |
| `antigravity-aegis` | Host CLI + vendored `rusty-loader` bootloader (multi-arch; only x86_64 UEFI is live) | mixed |
| `*_ALICE_1_0_BACKUP`, `.gemini/**/scratch` | Dev scaffolding. Never edit; never ship in review artifacts | — |

Detailed ground truth (verified model config, binary file formats, tokenizer
remapping, known dead code) lives in `references/architecture.md`. Read it before
touching inference math or file formats.

## Prime directives

These four rules exist because each one has already burned this project once.
Follow them on every task, even when the task doesn't mention them.

### 1. Measurement integrity is non-negotiable

The single biggest risk in this project is a fabricated number reaching a review
board. Invented metrics presented as measurements to a federal reviewer end
programs and careers — and they also mask real regressions during development.

- Every metric any code path prints (perplexity, TTFT, tokens/sec, RSS, cycle
  counts, "viability" verdicts) must be **computed at runtime from real work** in
  that same run. No hardcoded results, no "placeholder" numbers, no unconditional
  pass/fail verdicts — especially not in paths named for reviews or demos.
- If you encounter a mocked or hardcoded metric while doing *any* task, treat it as
  a P0 finding: fix it if in scope, otherwise surface it loudly to the user. Do not
  build features on top of it.
- Known offenders to check (verify current state — they may or may not be fixed
  yet): `aegis-eval/src/perplexity.rs` (hardcoded 14.12 / 14.58 PPL, comment says
  "Mock computation … for DARPA review"), the `antigravity` CLI `/benchmark` and
  `/status` (fixed TTFT 14ms / TPS 84.6 / RSS 412MB), the UEFI `/grant-review`
  command (unconditionally prints "Phase I Grant Viable"), and the UEFI
  `/benchmark` cycles→seconds conversion (assumes a fixed 2.5 GHz TSC).
- How to measure honestly (TSC calibration via CPUID 0x15, teacher-forced NLL for
  perplexity with the **pruned** tokenizer mapping, baseline methodology vs
  bitnet.cpp/llama.cpp) is specified in `references/performance.md` §Benchmarking
  and `references/grant-readiness.md`.

### 2. Trust code, not changelogs

The repo has contained changelog notes claiming fixes ("AUDIT RESOLUTION UPDATE")
that the code did not actually contain. Before building on any claimed fix,
**verify it in the current source**. Concretely: locate the exact lines, confirm
the behavior, and only then proceed. When you complete a fix yourself, the code and
any note you write must match — prefer letting the diff speak.

### 3. One source of truth for the embedding dtype

The project's worst correctness bug was prefill reading `EMBED.BIN` with a 2-byte
(BF16) stride while decode and the LM head read it with a 4-byte (F32) stride —
silently corrupting every prompt while decode still "worked." The deep cause:
`aegis-forge` slices raw bytes at whatever dtype the source safetensors uses, so
EMBED.BIN's dtype is a *property of the artifact*, not a constant of the code.

- At engine init, **derive** the element size from the file:
  `elem = embeddings.len() / (vocab_size * hidden_size)` and assert it is exactly 2
  or 4 with a message that names the actual byte length.
- Store that once (e.g., on the pipeline) and make **every** reader — prefill,
  decode, LM head, any future kernel — compute strides from it. Grep for
  `emb_dim * 2` / `emb_dim * 4` and `hidden * 2/4` literals whenever you touch
  embedding reads; a second independent stride constant is a bug waiting to happen.
- If forge output changes dtype (e.g., BF16-for-bandwidth), the loaders and kernels
  must consume the same derived value — never re-hardcode.

Run `python scripts/integrity_check.py <repo-root>` after any change to inference
math, file formats, or metrics code. It greps for stride splits, hardcoded file
sizes, mocked metrics, and fixed-clock assumptions, and exits nonzero on P0
findings. It is a tripwire, not a substitute for reading the code.

### 4. Respect the bare-metal constraints

`aegis-core` and `aegis-uefi` are `no_std` (+ `alloc`). No `std::` imports, no
threads, no OS syscalls. The hot loop is zero-allocation by design: all working
buffers live in `WorkingMemoryArena`, sized once at init. Never allocate inside
per-token or per-layer code — grow the arena instead. Firmware allocators on real
boards are broken in specific, documented ways; before changing anything about
boot, memory, or file loading, read `references/uefi-boot.md` — it records four
hardware-level bugs (XHCI 64KB DMA limit, FAT32 8.3 uppercase matching, boot-device
enumeration order, broken `AnyPages`) and the exact shipped fixes. Undoing one of
these "weird" patterns bricks the Acer test box.

## Version control & provenance

This project's recurring failure mode is claims drifting from code — hand-rolled
`_BACKUP` trees instead of history, changelogs describing fixes that don't exist.
Git is the countermeasure, and for the grant package it doubles as the provenance
layer: "these numbers came from commit `abc123` on this hardware" is a
reproducibility statement.

- **Never commit regenerable artifacts.** `.gitignore` must cover: `target/`,
  `MODEL.SAF` / `*.saf` / `*.safetensors`, `EMBED.BIN`, `VOCAB.BIN`, `*.img`,
  `*_ALICE_1_0_BACKUP*/`, `.gemini/`. The weights (~0.5GB each) exceed hosting
  limits and regenerate via aegis-forge from Microsoft's published model —
  document the regeneration command in the README instead of committing bytes.
- **One commit per logical change**; when a change claims a correctness or
  performance effect, the measurement (or parity-check result) goes in the commit
  message. A claimed fix is a diff, not a note.
- **Keep the repo private** until a deliberate release decision; run the
  grant-readiness naming scrub before any visibility change.
- **Embed the hash in the binary.** Have the build emit the commit hash (e.g., a
  `build.rs` running `git rev-parse --short HEAD`, `-dirty` suffix when the tree
  is modified) and print it in `/status` and `/benchmark` output, so every
  reported number self-identifies the exact code that produced it. This closes
  the loop on directive 2 mechanically.

## Task routing

- Coherence / wrong output / "ignores the prompt" → `references/architecture.md`
  (dtype invariant §, prefill/decode parity §) — start from the embedding stride
  and KV-cache write path before suspecting the kernels.
- Speed work → `references/performance.md` — has the kernel inventory, the ordered
  optimization roadmap (fused argmax LM head, vectorized attention loops, BF16
  widen-on-load, int8 activation milestone), and what *not* to touch (the 4-row LUT
  ternary matvec is good; keep it).
- Boot failures, new hardware, allocator, file loading → `references/uefi-boot.md`.
- Anything reviewer-facing: proposal text, demo scripts, benchmark reports,
  naming → `references/grant-readiness.md` — the package checklist, the novelty
  framing (lead with the systems contribution; the model is Microsoft's), the scope
  statement, and presentation hygiene.

## Definition of done

Before declaring any change complete:

1. `python scripts/integrity_check.py <repo-root>` passes (or every remaining
   finding is explicitly acknowledged by the user).
2. For inference-math changes: prefill/decode parity — running the same single
   token through `forward_batch` and `forward_step` must produce the same hidden
   state (write a quick check if one doesn't exist).
3. For boot/loader changes: boots under the `qemu-test` feature before anyone
   flashes a USB stick for real hardware.
4. For anything that prints a number: you can point to the runtime computation
   that produced it.
5. Backups and scratch dirs untouched; nothing reviewer-facing references them.
