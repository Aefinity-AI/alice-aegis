# A.L.I.C.E. — Phase I Novelty Claim & Scope Statement

*Draft for proposal integration. Bracketed `[measure: …]` items are pending
on-target measurements — they must be filled with real numbers or the sentence
removed before submission. Nothing in this document may ship with a placeholder.*

## Novelty claim

A.L.I.C.E. demonstrates **operating-system-less large-language-model inference
on commodity x86_64 hardware**: a `no_std` Rust unikernel that boots directly
from UEFI firmware, loads a 2-billion-parameter ternary transformer from
removable FAT32 media, and generates text with no kernel, no scheduler, no
drivers, and no software layer between the model and the silicon beyond the
firmware itself.

The contribution is the **systems path, not the model**. The network is
Microsoft's published BitNet b1.58-2B-4T; what does not previously exist in the
open literature is the infrastructure that runs it at ring 0 on stock firmware:

1. **A UEFI-native memory path for multi-hundred-megabyte tensors.** Production
   firmware allocators demonstrably refuse large contiguous requests
   (documented failure on DDR5 UMA platforms); A.L.I.C.E. sidesteps them with a
   raw physical-memory scanner that claims `EfiConventionalMemory` regions by
   exact address, plus a zero-allocation working arena that makes inference-time
   OOM structurally impossible.
2. **Hand-written AVX2 ternary kernels in `no_std` Rust** — LUT-decoded 2-bit
   weight unpacking fused into 4-row-unrolled FMA matvecs — with all activation
   state in preallocated buffers.
3. **Firmware-hardened I/O**: single-open FileInfo-sized loading through a
   64KB-aligned DMA bounce buffer (XHCI bulk-transfer compliant), boot-volume
   resolution via `LoadedImage` rather than enumeration order, uppercase-exact
   FAT32 8.3 access — each countermeasure mapped to a reproduced firmware
   defect on named retail hardware.

Why this matters for the mission space: eliminating the OS removes the largest
attack and failure surface in an edge AI appliance, makes boot-to-inference a
deterministic firmware-measurable sequence ([measure: cold-boot to first token,
seconds]), and yields a single auditable binary whose provenance is pinned to a
build hash printed in its own telemetry.

## Scope statement

Phase I scope is deliberately narrow, and stated limits are design decisions:

- **Hardware:** modern x86_64 UEFI platforms with AVX2; single core. Validated
  on [list actual boards tested]. No aarch64/riscv64 claim is made.
- **Model:** BitNet b1.58-2B-4T, weights as published by Microsoft; f32
  activations (accuracy-over-speed; the int8 activation path is a stated
  Phase II milestone, not an implied capability).
- **Vocabulary:** pruned to 50,189 tokens — English/ASCII only, by
  construction. Measured quality cost on WikiText-2: [measure: pruned PPL vs
  reference-tooling baseline, same corpus and window policy].
- **Decoding:** greedy argmax; deterministic given identical inputs. No
  sampling claims.
- **Throughput:** [measure: cycles/token and, where CPUID 0x15 enumerates TSC
  frequency, tokens/sec on named hardware], reported beside like-for-like
  bitnet.cpp and llama.cpp runs on the same machine — including comparisons we
  lose.
- **Out of scope for Phase I:** multi-core, non-English text, networked
  operation, model training or fine-tuning, and any resilience claim (ECC,
  thermal, malformed-input behavior) not backed by a documented test.

Every quantitative claim above is either filled from an on-target measurement
traceable to a git commit hash, or the claim is withdrawn.
